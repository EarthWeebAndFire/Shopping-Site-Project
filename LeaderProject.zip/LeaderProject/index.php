<?php
 //Connect to Database  
 $hostname = "localhost";
 $username = "ecpi_user";
 $password = "Password1";
 $dbname = "webpage products";
 $conn = mysqli_connect($hostname, $username, $password, $dbname);
     
 //Query for all users
 $query = "SELECT * FROM products";
 $result = mysqli_query($conn, $query);

 //Code for subtracting order selection from database
 if (isset($_POST['submit_order'])) {
    $productIds = $_POST['ProductNo'];
    $orderAmounts = $_POST['order_amount'];

    for ($i = 0; $i < count($productIds); $i++) {
        $productId = intval($productIds[$i]);
        $orderAmount = intval($orderAmounts[$i]);

        if ($orderAmount > 0) {
            //Checks current number of items in stock
            $checkQuery = "SELECT ProductQuant FROM products WHERE ProductNo = $productId";
            $checkResult = mysqli_query($conn, $checkQuery);
            if ($checkResult && mysqli_num_rows($checkResult) > 0) {
                $current = mysqli_fetch_assoc($checkResult)['ProductQuant'];

                //Only subtracts whats available to make sure we dont go into negative on database
                $amountToSubtract = min($orderAmount, $current);
                $newQuantity = $current - $amountToSubtract;

                $updateQuery = "UPDATE products SET ProductQuant = $newQuantity WHERE ProductNo = $productId";
                if (!mysqli_query($conn, $updateQuery)) {
                    echo "Error updating product $productId: " . mysqli_error($conn);
                }

                //Displays that the user is trying to order more of an item than there is in stock
                if ($orderAmount > $current) {
                    echo "<script>alert('You requested $orderAmount units of Product #$productId, but only $current were available. Order adjusted to $current.');</script>";
                }
            }
        }
    }

    //Refreshes the page to show changes
    echo "<script>window.location = window.location.href;</script>";
}
?>

<head>
    <!--webpage stylization-->
    <meta charset="UTF-8">
    <title>Webpage Project Shop</title>
    <style>
        table {
            width: 60%;
            border-collapse: collapse;
            margin: 20px auto;
            text-align: center;
        }
        th, td {
            border: 1px solid #999;
            padding: 10px;
        }
        select {
            width: 60px;
        }
        button {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
        }
    </style>
</head>
<html>
<body>

    <h2 style="text-align: center;">Available Products</h2>
    
    <!--Product name, Number, price, and quanitity available to order, will be subject to change when connected to the database-->
    <form method="post" action="">
<table>
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Order Amount</th>
    </tr>
    <?php
    //Loop that displays product table from database and gives a dropdown to order x ammount of product
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['ProductName']) . "</td>";
            echo "<td>" . htmlspecialchars($row['ProductQuant']) . "</td>";
            echo "<td>$" . htmlspecialchars($row['ProductPrice']) . "</td>";
            echo "<td>
                    <input type='hidden' name='ProductNo[]' value='" . $row['ProductNo'] . "'>
                    <select name='order_amount[]'>
                        <option value='0'>0</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No products found</td></tr>";
    }
    ?>
</table>
    <!--button changes number of items in stock and refreshes the page-->
    <button type="submit" name="submit_order">Place Order</button>
</form>
</body>
</html>
